#' magrittr forward-pipe operator
#' @name %>%
#' @importFrom magrittr %>%
#' @export
#' @keywords internal
NULL