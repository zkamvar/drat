library(testthat)
options(poppr.debug = TRUE)
test_check("poppr")