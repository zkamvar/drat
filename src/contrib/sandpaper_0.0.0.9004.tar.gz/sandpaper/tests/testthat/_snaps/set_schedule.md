# set_schedule() will display the modifications if write is not specified

    carpentry: cp
    title: Lesson Title
    life_cycle: pre-alpha
    license: CC-BY 4.0
    source: https://github.com/carpentries/sandpaper
    branch: main
    contact: team@carpentries.org
    
    schedule:
    - 01-introduction.Rmd
    x 02-new.Rmd

