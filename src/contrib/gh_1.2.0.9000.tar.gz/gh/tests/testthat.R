library(testthat)
library(gh)

test_check("gh")
