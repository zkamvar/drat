library(testthat)
library(dovetail)

test_check("dovetail")
