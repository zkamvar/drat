library(testthat)
suppressPackageStartupMessages(library(adegenet))
test_check("adegenet")
