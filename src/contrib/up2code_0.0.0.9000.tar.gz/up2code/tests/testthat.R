library(testthat)
library(up2code)

test_check("up2code")
