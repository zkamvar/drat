repvar 0.1.0
============

* Initial version of repvar
