library(testthat)
library(repvar)

test_check("repvar")
