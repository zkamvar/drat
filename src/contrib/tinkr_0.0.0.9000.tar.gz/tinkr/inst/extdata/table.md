---
title: "What have these birds been studied for? Querying science outputs with R"
---



| A column | Another column | A third column |   |   |
|----------|----------------|----------------|---|---|
| a        | a              | a              |   |   |
| a        | a              | a              |   |   |
|          |                |                |   |   |


| a | b | c | d | 
| : | - | :: | : |
| l | n | c | r | 
