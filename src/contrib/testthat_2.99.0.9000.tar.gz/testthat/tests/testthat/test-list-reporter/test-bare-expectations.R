test_that("before", expect_true(TRUE))

# this is a bare expectation
expect_true(TRUE)

test_that("after", expect_true(TRUE))
